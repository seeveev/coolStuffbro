({
	recordUpdate: function(component, event, helper) {
        alert(component.get("v.record").Name);
    }
 
})